# Design Guidelines: All-in-One India Calculator Hub

## Design Approach
**System Selected:** Material Design principles adapted for utility applications
**Rationale:** Calculator tools require clarity, efficiency, and familiar interaction patterns. Material Design's emphasis on structured layouts, clear hierarchy, and functional components aligns perfectly with this productivity-focused application.

## Layout System

### Spacing Primitives
Use Tailwind units: **2, 4, 6, 8, 12, 16, 20** for consistent rhythm
- Component padding: p-4 to p-6 (mobile), p-6 to p-8 (desktop)
- Section spacing: mb-8 to mb-12 between calculator cards
- Input field gaps: gap-4 within forms, gap-6 between form sections
- Container margins: mx-4 (mobile), mx-auto with max-w-7xl (desktop)

### Grid Structure
- Main container: max-w-6xl centered with responsive padding
- Calculator cards: Single column on mobile, 2-column grid on tablets (md:grid-cols-2), maintain single focused card on desktop for better UX
- Navigation tabs: Horizontal scrollable on mobile, fixed horizontal bar on desktop
- Form layouts: Single column inputs with full-width buttons below

## Typography Hierarchy

**Font Stack:** Google Fonts - Inter (primary), Roboto Mono (numerical displays)

### Text Sizes
- Main Header (India Calculator Hub): text-3xl md:text-4xl, font-bold
- Section Headers (Calculator Titles): text-xl md:text-2xl, font-semibold
- Input Labels: text-sm, font-medium, uppercase tracking-wide
- Body Text/Instructions: text-base, leading-relaxed
- Result Display: text-2xl md:text-3xl, font-bold (Roboto Mono)
- Helper Text: text-sm, opacity-75

## Component Library

### Header Component
- Fixed top bar with flag emoji + title
- Height: h-16 md:h-20
- Navigation tabs integrated below header with smooth scroll indicators
- Subtle shadow for depth (shadow-sm)

### Navigation Tabs
- Pill-style buttons with rounded-full edges
- Active state: filled background with indicator bar below
- Responsive: horizontal scroll on mobile, centered flex layout on desktop
- Spacing: gap-2 between tabs, px-4 py-2 per tab

### Calculator Cards
- Elevated cards with rounded-xl corners
- Consistent padding: p-6 md:p-8
- Card header with icon + title, subtitle line underneath
- Collapsible sections with smooth expansion (max-height transition)
- Clear visual separation between input area and results area

### Form Elements
**Input Fields:**
- Full-width with rounded-lg borders
- Height: h-12 for consistency
- Floating labels or clear top-aligned labels with text-sm
- Focus states with ring effect (ring-2)
- Number inputs with step controls visible

**Buttons:**
- Primary CTA: Full-width on mobile, max-w-xs on desktop
- Height: h-12, rounded-lg
- Calculate buttons: prominent with icon (calculator symbol)
- Clear/Reset buttons: Secondary style, smaller, positioned top-right of results

**Dropdowns/Selects:**
- Match input field styling (h-12, rounded-lg)
- Custom arrow indicator for consistency

### Results Display
- Distinct visual container separate from inputs
- Background treatment to differentiate from input area
- Large, clear numerical display with Roboto Mono
- Breakdown details below primary result (smaller text-sm)
- Success indicator (checkmark icon) when calculation completes

### Ad Banner Placeholder
- Fixed aspect ratio container: aspect-[728/90] for desktop leaderboard
- Centered with max-w-3xl
- Positioned between header and main content, or between calculator sections
- Subtle border to indicate ad space

### Footer
- Three-column layout on desktop, stacked on mobile
- Links: About | Privacy Policy | Disclaimer with dividers
- Small text (text-xs), centered alignment
- Copyright notice with year
- Padding: py-8, border-top for separation

## Interactions & Micro-animations

**Minimal Animation Strategy:**
- Card expansion/collapse: 300ms ease-in-out
- Button press: Scale down slightly (scale-95) on active state
- Input focus: Smooth ring expansion
- Result reveal: Fade-in with slight upward motion (150ms)
- Tab switching: Content crossfade (200ms)

**NO animations for:** Loading states (use simple spinner), hover effects on results, continuous/looping animations

## Mobile-First Considerations

**Breakpoints:**
- Mobile: < 768px - Single column, full-width inputs, stacked navigation
- Tablet: 768px - 1024px - 2-column grids where appropriate, horizontal tabs
- Desktop: > 1024px - Centered container, optimal line lengths

**Touch Targets:**
- Minimum 44px height for all interactive elements
- Increased padding on mobile: p-4 minimum for tap areas
- Spacing between clickable elements: gap-3 minimum

## Accessibility Standards
- Form labels explicitly associated with inputs
- ARIA labels for icon-only buttons
- Keyboard navigation support for all calculators
- Error states clearly indicated with text (not just visual)
- Sufficient contrast ratios throughout
- Focus indicators visible on all interactive elements

## Calculator-Specific Patterns
- GST Calculator: Radio buttons for rate selection (5%, 12%, 18%, 28%)
- EMI Calculator: Slider for tenure with numerical input option
- BMI Calculator: Unit toggle (kg/cm vs lbs/inches)
- Age Calculator: Date picker with fallback to three dropdowns
- Income Tax: Regime selector (Old vs New) as prominent toggle

## Images
**No hero image required** - This is a utility application where immediate functionality takes precedence over visual storytelling. The header with flag emoji and clear title provides sufficient context.