import { useState } from "react";
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ThemeProvider";
import { GSTCalculator } from "@/components/calculators/GSTCalculator";
import { EMICalculator } from "@/components/calculators/EMICalculator";
import { BMICalculator } from "@/components/calculators/BMICalculator";
import { AgeCalculator } from "@/components/calculators/AgeCalculator";
import { IncomeTaxCalculator } from "@/components/calculators/IncomeTaxCalculator";
import { UnitConverter } from "@/components/calculators/UnitConverter";
import { SIPCalculator } from "@/components/calculators/SIPCalculator";
import { PPFCalculator } from "@/components/calculators/PPFCalculator";
import { GratuityCalculator } from "@/components/calculators/GratuityCalculator";
import { TipCalculator } from "@/components/calculators/TipCalculator";
import { Footer } from "@/components/Footer";

type TabCategory = "Finance" | "Health" | "Conversion" | "Daily Tools";

export default function Home() {
  const { theme, setTheme } = useTheme();
  const [activeTab, setActiveTab] = useState<TabCategory>("Finance");

  const tabs: TabCategory[] = ["Finance", "Health", "Conversion", "Daily Tools"];

  const renderCalculators = () => {
    switch (activeTab) {
      case "Finance":
        return (
          <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2">
            <GSTCalculator />
            <EMICalculator />
            <IncomeTaxCalculator />
            <SIPCalculator />
            <PPFCalculator />
            <GratuityCalculator />
          </div>
        );
      case "Health":
        return (
          <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2">
            <BMICalculator />
          </div>
        );
      case "Conversion":
        return (
          <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2">
            <UnitConverter />
          </div>
        );
      case "Daily Tools":
        return (
          <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2">
            <AgeCalculator />
            <TipCalculator />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 flex h-16 md:h-20 items-center justify-between gap-4">
          <h1 className="text-xl md:text-2xl lg:text-3xl font-bold" data-testid="text-header">
            <span className="bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent">
              All-in-One India Calculator
            </span>
          </h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="rounded-full shrink-0"
            data-testid="button-theme-toggle"
          >
            {theme === "light" ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </header>

      <div
        id="adsense-banner"
        className="max-w-3xl mx-auto my-6 px-4 w-full"
        data-testid="div-adsense-banner"
      >
        <div className="aspect-[728/90] bg-muted border border-border rounded-lg flex items-center justify-center">
          <p className="text-sm text-muted-foreground">Advertisement Space</p>
        </div>
      </div>

      <nav className="border-b bg-card sticky top-16 md:top-20 z-40">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide py-3">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2 rounded-full font-medium text-sm whitespace-nowrap transition-all hover-elevate active-elevate-2 ${
                  activeTab === tab
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "bg-muted text-muted-foreground hover:bg-accent"
                }`}
                data-testid={`button-tab-${tab.toLowerCase().replace(" ", "-")}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">{activeTab}</h2>
          <p className="text-muted-foreground">
            {activeTab === "Finance" && "Calculate GST, EMI, Income Tax, SIP, PPF, and Gratuity"}
            {activeTab === "Health" && "Track your health metrics and wellness"}
            {activeTab === "Conversion" && "Convert between different units of measurement"}
            {activeTab === "Daily Tools" && "Useful everyday calculators including Age and Tip"}
          </p>
        </div>
        {renderCalculators()}
      </main>

      <Footer />
    </div>
  );
}
