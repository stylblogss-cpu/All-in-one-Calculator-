import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calculator, Info } from "lucide-react";

type TaxRegime = "old" | "new";

export function IncomeTaxCalculator() {
  const [income, setIncome] = useState("");
  const [regime, setRegime] = useState<TaxRegime>("new");
  const [result, setResult] = useState<{
    totalTax: number;
    netIncome: number;
    effectiveRate: number;
    breakdown: { slab: string; tax: number }[];
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateNewRegime = (income: number) => {
    const breakdown: { slab: string; tax: number }[] = [];
    let tax = 0;

    if (income <= 300000) {
      breakdown.push({ slab: "₹0 - ₹3,00,000", tax: 0 });
    } else if (income <= 700000) {
      const taxable = income - 300000;
      tax = taxable * 0.05;
      breakdown.push({ slab: "₹3,00,001 - ₹7,00,000 @ 5%", tax });
    } else if (income <= 1000000) {
      tax = 400000 * 0.05;
      const taxable = income - 700000;
      const currentTax = taxable * 0.1;
      breakdown.push({ slab: "₹3,00,001 - ₹7,00,000 @ 5%", tax });
      breakdown.push({ slab: "₹7,00,001 - ₹10,00,000 @ 10%", tax: currentTax });
      tax += currentTax;
    } else if (income <= 1200000) {
      tax = 400000 * 0.05 + 300000 * 0.1;
      const taxable = income - 1000000;
      const currentTax = taxable * 0.15;
      breakdown.push({ slab: "₹3,00,001 - ₹7,00,000 @ 5%", tax: 20000 });
      breakdown.push({ slab: "₹7,00,001 - ₹10,00,000 @ 10%", tax: 30000 });
      breakdown.push({ slab: "₹10,00,001 - ₹12,00,000 @ 15%", tax: currentTax });
      tax += currentTax;
    } else if (income <= 1500000) {
      tax = 400000 * 0.05 + 300000 * 0.1 + 200000 * 0.15;
      const taxable = income - 1200000;
      const currentTax = taxable * 0.2;
      breakdown.push({ slab: "₹3,00,001 - ₹7,00,000 @ 5%", tax: 20000 });
      breakdown.push({ slab: "₹7,00,001 - ₹10,00,000 @ 10%", tax: 30000 });
      breakdown.push({ slab: "₹10,00,001 - ₹12,00,000 @ 15%", tax: 30000 });
      breakdown.push({ slab: "₹12,00,001 - ₹15,00,000 @ 20%", tax: currentTax });
      tax += currentTax;
    } else {
      tax = 400000 * 0.05 + 300000 * 0.1 + 200000 * 0.15 + 300000 * 0.2;
      const taxable = income - 1500000;
      const currentTax = taxable * 0.3;
      breakdown.push({ slab: "₹3,00,001 - ₹7,00,000 @ 5%", tax: 20000 });
      breakdown.push({ slab: "₹7,00,001 - ₹10,00,000 @ 10%", tax: 30000 });
      breakdown.push({ slab: "₹10,00,001 - ₹12,00,000 @ 15%", tax: 30000 });
      breakdown.push({ slab: "₹12,00,001 - ₹15,00,000 @ 20%", tax: 60000 });
      breakdown.push({ slab: "Above ₹15,00,000 @ 30%", tax: currentTax });
      tax += currentTax;
    }

    return { tax, breakdown };
  };

  const calculateOldRegime = (income: number) => {
    const breakdown: { slab: string; tax: number }[] = [];
    let tax = 0;

    if (income <= 250000) {
      breakdown.push({ slab: "₹0 - ₹2,50,000", tax: 0 });
    } else if (income <= 500000) {
      const taxable = income - 250000;
      tax = taxable * 0.05;
      breakdown.push({ slab: "₹2,50,001 - ₹5,00,000 @ 5%", tax });
    } else if (income <= 1000000) {
      tax = 250000 * 0.05;
      const taxable = income - 500000;
      const currentTax = taxable * 0.2;
      breakdown.push({ slab: "₹2,50,001 - ₹5,00,000 @ 5%", tax: 12500 });
      breakdown.push({ slab: "₹5,00,001 - ₹10,00,000 @ 20%", tax: currentTax });
      tax += currentTax;
    } else {
      tax = 250000 * 0.05 + 500000 * 0.2;
      const taxable = income - 1000000;
      const currentTax = taxable * 0.3;
      breakdown.push({ slab: "₹2,50,001 - ₹5,00,000 @ 5%", tax: 12500 });
      breakdown.push({ slab: "₹5,00,001 - ₹10,00,000 @ 20%", tax: 100000 });
      breakdown.push({ slab: "Above ₹10,00,000 @ 30%", tax: currentTax });
      tax += currentTax;
    }

    return { tax, breakdown };
  };

  const calculateTax = () => {
    const annualIncome = parseFloat(income);
    if (isNaN(annualIncome) || annualIncome <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      const { tax, breakdown } =
        regime === "new" ? calculateNewRegime(annualIncome) : calculateOldRegime(annualIncome);

      const cess = tax * 0.04;
      const totalTax = Math.round((tax + cess) * 100) / 100;
      const netIncome = annualIncome - totalTax;
      const effectiveRate = (totalTax / annualIncome) * 100;

      setResult({
        totalTax,
        netIncome,
        effectiveRate: Math.round(effectiveRate * 100) / 100,
        breakdown,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setIncome("");
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Calculator className="h-6 w-6 text-primary" />
          Income Tax Calculator 2025
        </CardTitle>
        <CardDescription>
          Calculate your income tax liability under old or new tax regime
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tax-income" className="text-sm font-medium uppercase tracking-wide">
              Annual Income (₹)
            </Label>
            <Input
              id="tax-income"
              data-testid="input-tax-income"
              type="number"
              placeholder="Enter annual income"
              value={income}
              onChange={(e) => setIncome(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium uppercase tracking-wide">Tax Regime</Label>
            <RadioGroup
              value={regime}
              onValueChange={(value) => setRegime(value as TaxRegime)}
              className="grid grid-cols-1 md:grid-cols-2 gap-3"
            >
              <label
                className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                  regime === "new" ? "border-primary bg-primary/5" : "border-border"
                }`}
                data-testid="radio-tax-new"
              >
                <RadioGroupItem value="new" id="tax-new" />
                <div className="flex-1">
                  <span className="font-medium block">New Regime</span>
                  <span className="text-xs text-muted-foreground">No deductions, lower rates</span>
                </div>
              </label>
              <label
                className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                  regime === "old" ? "border-primary bg-primary/5" : "border-border"
                }`}
                data-testid="radio-tax-old"
              >
                <RadioGroupItem value="old" id="tax-old" />
                <div className="flex-1">
                  <span className="font-medium block">Old Regime</span>
                  <span className="text-xs text-muted-foreground">With deductions, higher rates</span>
                </div>
              </label>
            </RadioGroup>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateTax}
              className="flex-1 h-12"
              disabled={!income || isCalculating}
              data-testid="button-calculate-tax"
            >
              {isCalculating ? "Calculating..." : "Calculate Tax"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-tax"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Tax Summary</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Total Tax:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-tax-total">
                  ₹{result.totalTax.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Net Income:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-tax-net">
                  ₹{result.netIncome.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Effective Tax Rate:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-tax-rate">
                  {result.effectiveRate}%
                </span>
              </div>
              {result.breakdown.length > 0 && (
                <div className="space-y-2 pt-2">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    Tax Breakdown:
                  </p>
                  {result.breakdown.map((item, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center text-sm p-2 bg-accent/50 rounded"
                    >
                      <span className="text-muted-foreground">{item.slab}</span>
                      <span className="font-mono font-medium">
                        ₹{item.tax.toLocaleString("en-IN")}
                      </span>
                    </div>
                  ))}
                  <p className="text-xs text-muted-foreground pt-1">
                    * Includes 4% Health & Education Cess
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
