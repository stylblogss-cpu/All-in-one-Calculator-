import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Briefcase, Info } from "lucide-react";

export function GratuityCalculator() {
  const [lastSalary, setLastSalary] = useState("");
  const [yearsOfService, setYearsOfService] = useState("");
  const [result, setResult] = useState<{
    gratuityAmount: number;
    eligibility: string;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateGratuity = () => {
    const salary = parseFloat(lastSalary);
    const years = parseFloat(yearsOfService);

    if (isNaN(salary) || isNaN(years) || salary <= 0 || years <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      const gratuityAmount = (salary * years * 15) / 26;
      const eligibility = years >= 5 ? "Eligible" : "Not Eligible (Minimum 5 years required)";

      setResult({
        gratuityAmount: Math.round(gratuityAmount * 100) / 100,
        eligibility,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setLastSalary("");
    setYearsOfService("");
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Briefcase className="h-6 w-6 text-primary" />
          Gratuity Calculator
        </CardTitle>
        <CardDescription>
          Calculate your gratuity amount based on salary and years of service
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="gratuity-salary" className="text-sm font-medium uppercase tracking-wide">
              Last Drawn Salary (₹)
            </Label>
            <Input
              id="gratuity-salary"
              data-testid="input-gratuity-salary"
              type="number"
              placeholder="Enter your last drawn monthly salary"
              value={lastSalary}
              onChange={(e) => setLastSalary(e.target.value)}
              className="h-12 text-base"
            />
            <p className="text-xs text-muted-foreground">
              Basic salary + Dearness Allowance (DA)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="gratuity-years" className="text-sm font-medium uppercase tracking-wide">
              Years of Service
            </Label>
            <Input
              id="gratuity-years"
              data-testid="input-gratuity-years"
              type="number"
              step="0.5"
              placeholder="Enter total years of service"
              value={yearsOfService}
              onChange={(e) => setYearsOfService(e.target.value)}
              className="h-12 text-base"
            />
            <p className="text-xs text-muted-foreground">
              Minimum 5 years required for gratuity eligibility
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateGratuity}
              className="flex-1 h-12"
              disabled={!lastSalary || !yearsOfService || isCalculating}
              data-testid="button-calculate-gratuity"
            >
              {isCalculating ? "Calculating..." : "Calculate Gratuity"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-gratuity"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Gratuity Details</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Eligibility Status:</span>
                <span 
                  className={`text-lg font-bold ${
                    result.eligibility === "Eligible" ? "text-secondary" : "text-destructive"
                  }`}
                  data-testid="text-gratuity-eligibility"
                >
                  {result.eligibility}
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Gratuity Amount:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-gratuity-amount">
                  ₹{result.gratuityAmount.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="p-3 bg-accent rounded-lg">
                <p className="text-xs text-muted-foreground">
                  Formula: (Last Salary × Years of Service × 15) ÷ 26
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Note: This is an approximate calculation for employees covered under the Payment of Gratuity Act, 1972
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
