import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeftRight, Info } from "lucide-react";

type UnitCategory = "length" | "weight" | "temperature";

type ConversionUnit = {
  name: string;
  value: string;
  toBase: (val: number) => number;
  fromBase: (val: number) => number;
};

const lengthUnits: ConversionUnit[] = [
  { name: "Kilometers", value: "km", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
  { name: "Meters", value: "m", toBase: (v) => v, fromBase: (v) => v },
  { name: "Centimeters", value: "cm", toBase: (v) => v / 100, fromBase: (v) => v * 100 },
  { name: "Miles", value: "mi", toBase: (v) => v * 1609.34, fromBase: (v) => v / 1609.34 },
  { name: "Feet", value: "ft", toBase: (v) => v * 0.3048, fromBase: (v) => v / 0.3048 },
  { name: "Inches", value: "in", toBase: (v) => v * 0.0254, fromBase: (v) => v / 0.0254 },
];

const weightUnits: ConversionUnit[] = [
  { name: "Kilograms", value: "kg", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
  { name: "Grams", value: "g", toBase: (v) => v, fromBase: (v) => v },
  { name: "Pounds", value: "lb", toBase: (v) => v * 453.592, fromBase: (v) => v / 453.592 },
  { name: "Ounces", value: "oz", toBase: (v) => v * 28.3495, fromBase: (v) => v / 28.3495 },
];

const temperatureUnits: ConversionUnit[] = [
  {
    name: "Celsius",
    value: "c",
    toBase: (v) => v,
    fromBase: (v) => v,
  },
  {
    name: "Fahrenheit",
    value: "f",
    toBase: (v) => (v - 32) * (5 / 9),
    fromBase: (v) => v * (9 / 5) + 32,
  },
  {
    name: "Kelvin",
    value: "k",
    toBase: (v) => v - 273.15,
    fromBase: (v) => v + 273.15,
  },
];

export function UnitConverter() {
  const [category, setCategory] = useState<UnitCategory>("length");
  const [fromUnit, setFromUnit] = useState("km");
  const [toUnit, setToUnit] = useState("mi");
  const [inputValue, setInputValue] = useState("");
  const [result, setResult] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const getUnits = () => {
    switch (category) {
      case "length":
        return lengthUnits;
      case "weight":
        return weightUnits;
      case "temperature":
        return temperatureUnits;
      default:
        return lengthUnits;
    }
  };

  const handleCategoryChange = (newCategory: UnitCategory) => {
    setCategory(newCategory);
    const units = newCategory === "length" ? lengthUnits : newCategory === "weight" ? weightUnits : temperatureUnits;
    setFromUnit(units[0].value);
    setToUnit(units[1].value);
    setInputValue("");
    setResult(null);
  };

  const convertUnits = () => {
    const value = parseFloat(inputValue);
    if (isNaN(value)) return;

    setIsCalculating(true);
    setTimeout(() => {
      const units = getUnits();
      const fromUnitObj = units.find((u) => u.value === fromUnit);
      const toUnitObj = units.find((u) => u.value === toUnit);

      if (!fromUnitObj || !toUnitObj) return;

      const baseValue = fromUnitObj.toBase(value);
      const convertedValue = toUnitObj.fromBase(baseValue);
      setResult(Math.round(convertedValue * 100000) / 100000);
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setInputValue("");
    setResult(null);
  };

  const units = getUnits();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <ArrowLeftRight className="h-6 w-6 text-primary" />
          Unit Converter
        </CardTitle>
        <CardDescription>
          Convert between different units of measurement
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="converter-category" className="text-sm font-medium uppercase tracking-wide">
              Category
            </Label>
            <Select value={category} onValueChange={(value) => handleCategoryChange(value as UnitCategory)}>
              <SelectTrigger className="h-12" data-testid="select-converter-category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="length" data-testid="select-item-category-length">Length / Distance</SelectItem>
                <SelectItem value="weight" data-testid="select-item-category-weight">Weight / Mass</SelectItem>
                <SelectItem value="temperature" data-testid="select-item-category-temperature">Temperature</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="converter-from" className="text-sm font-medium uppercase tracking-wide">
                From
              </Label>
              <Select value={fromUnit} onValueChange={setFromUnit}>
                <SelectTrigger className="h-12" data-testid="select-converter-from">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {units.map((unit) => (
                    <SelectItem key={unit.value} value={unit.value} data-testid={`select-item-from-${unit.value}`}>
                      {unit.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="converter-to" className="text-sm font-medium uppercase tracking-wide">
                To
              </Label>
              <Select value={toUnit} onValueChange={setToUnit}>
                <SelectTrigger className="h-12" data-testid="select-converter-to">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {units.map((unit) => (
                    <SelectItem key={unit.value} value={unit.value} data-testid={`select-item-to-${unit.value}`}>
                      {unit.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="converter-value" className="text-sm font-medium uppercase tracking-wide">
              Value
            </Label>
            <Input
              id="converter-value"
              data-testid="input-converter-value"
              type="number"
              step="any"
              placeholder="Enter value to convert"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={convertUnits}
              className="flex-1 h-12"
              disabled={!inputValue || isCalculating}
              data-testid="button-convert"
            >
              {isCalculating ? "Converting..." : "Convert"}
            </Button>
            {result !== null && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-converter"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result !== null && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Result</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Converted Value:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-converter-result">
                  {result.toLocaleString("en-IN")} {units.find((u) => u.value === toUnit)?.name}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Original:</span>
                <span className="text-lg font-bold font-mono">
                  {parseFloat(inputValue).toLocaleString("en-IN")} {units.find((u) => u.value === fromUnit)?.name}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
