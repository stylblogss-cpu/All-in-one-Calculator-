import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Activity, Info } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

type BMICategory = {
  category: string;
  color: string;
  description: string;
};

export function BMICalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [unit, setUnit] = useState<"metric" | "imperial">("metric");
  const [result, setResult] = useState<{
    bmi: number;
    category: BMICategory;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const getBMICategory = (bmi: number): BMICategory => {
    if (bmi < 18.5) {
      return {
        category: "Underweight",
        color: "text-blue-600 dark:text-blue-400",
        description: "Below normal weight",
      };
    } else if (bmi >= 18.5 && bmi < 25) {
      return {
        category: "Normal",
        color: "text-secondary",
        description: "Healthy weight range",
      };
    } else if (bmi >= 25 && bmi < 30) {
      return {
        category: "Overweight",
        color: "text-yellow-600 dark:text-yellow-500",
        description: "Above normal weight",
      };
    } else {
      return {
        category: "Obese",
        color: "text-destructive",
        description: "Significantly above normal weight",
      };
    }
  };

  const calculateBMI = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);

    if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      let bmi: number;
      if (unit === "metric") {
        const heightInMeters = h / 100;
        bmi = w / (heightInMeters * heightInMeters);
      } else {
        bmi = (w / (h * h)) * 703;
      }

      const roundedBMI = Math.round(bmi * 10) / 10;
      setResult({
        bmi: roundedBMI,
        category: getBMICategory(roundedBMI),
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setWeight("");
    setHeight("");
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Activity className="h-6 w-6 text-primary" />
          BMI Calculator
        </CardTitle>
        <CardDescription>
          Calculate your Body Mass Index and check your health category
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium uppercase tracking-wide">Unit System</Label>
            <RadioGroup
              value={unit}
              onValueChange={(value) => setUnit(value as "metric" | "imperial")}
              className="grid grid-cols-2 gap-3"
            >
              <label
                className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                  unit === "metric" ? "border-primary bg-primary/5" : "border-border"
                }`}
                data-testid="radio-bmi-metric"
              >
                <RadioGroupItem value="metric" id="bmi-metric" />
                <span className="font-medium">Metric (kg, cm)</span>
              </label>
              <label
                className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                  unit === "imperial" ? "border-primary bg-primary/5" : "border-border"
                }`}
                data-testid="radio-bmi-imperial"
              >
                <RadioGroupItem value="imperial" id="bmi-imperial" />
                <span className="font-medium">Imperial (lbs, in)</span>
              </label>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bmi-weight" className="text-sm font-medium uppercase tracking-wide">
              Weight ({unit === "metric" ? "kg" : "lbs"})
            </Label>
            <Input
              id="bmi-weight"
              data-testid="input-bmi-weight"
              type="number"
              step="0.1"
              placeholder={`Enter weight in ${unit === "metric" ? "kilograms" : "pounds"}`}
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bmi-height" className="text-sm font-medium uppercase tracking-wide">
              Height ({unit === "metric" ? "cm" : "inches"})
            </Label>
            <Input
              id="bmi-height"
              data-testid="input-bmi-height"
              type="number"
              step="0.1"
              placeholder={`Enter height in ${unit === "metric" ? "centimeters" : "inches"}`}
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateBMI}
              className="flex-1 h-12"
              disabled={!weight || !height || isCalculating}
              data-testid="button-calculate-bmi"
            >
              {isCalculating ? "Calculating..." : "Calculate BMI"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-bmi"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Results</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Your BMI:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-bmi-value">
                  {result.bmi}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Category:</span>
                <span className={`text-xl font-bold ${result.category.color}`} data-testid="text-bmi-category">
                  {result.category.category}
                </span>
              </div>
              <div className="p-3 bg-accent rounded-lg">
                <p className="text-sm text-muted-foreground text-center">
                  {result.category.description}
                </p>
              </div>
              <div className="text-xs text-muted-foreground space-y-1 pt-2">
                <p>BMI Categories:</p>
                <p>• Underweight: &lt; 18.5</p>
                <p>• Normal: 18.5 - 24.9</p>
                <p>• Overweight: 25 - 29.9</p>
                <p>• Obese: ≥ 30</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
