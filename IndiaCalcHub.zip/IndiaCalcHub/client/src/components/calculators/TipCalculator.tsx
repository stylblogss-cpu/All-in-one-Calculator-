import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Utensils, Info } from "lucide-react";

export function TipCalculator() {
  const [billAmount, setBillAmount] = useState("");
  const [tipPercentage, setTipPercentage] = useState("10");
  const [numberOfPeople, setNumberOfPeople] = useState("1");
  const [result, setResult] = useState<{
    tipAmount: number;
    totalAmount: number;
    perPersonAmount: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateTip = () => {
    const bill = parseFloat(billAmount);
    const tip = parseFloat(tipPercentage);
    const people = parseInt(numberOfPeople);

    if (isNaN(bill) || isNaN(tip) || isNaN(people) || bill <= 0 || tip < 0 || people <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      const tipAmount = (bill * tip) / 100;
      const totalAmount = bill + tipAmount;
      const perPersonAmount = totalAmount / people;

      setResult({
        tipAmount: Math.round(tipAmount * 100) / 100,
        totalAmount: Math.round(totalAmount * 100) / 100,
        perPersonAmount: Math.round(perPersonAmount * 100) / 100,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setBillAmount("");
    setTipPercentage("10");
    setNumberOfPeople("1");
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Utensils className="h-6 w-6 text-primary" />
          Tip Calculator
        </CardTitle>
        <CardDescription>
          Calculate tip amount and split the bill among multiple people
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tip-bill" className="text-sm font-medium uppercase tracking-wide">
              Bill Amount (₹)
            </Label>
            <Input
              id="tip-bill"
              data-testid="input-tip-bill"
              type="number"
              placeholder="Enter bill amount"
              value={billAmount}
              onChange={(e) => setBillAmount(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium uppercase tracking-wide">Tip Percentage</Label>
            <RadioGroup
              value={tipPercentage}
              onValueChange={setTipPercentage}
              className="grid grid-cols-2 md:grid-cols-4 gap-3"
            >
              {["5", "10", "15", "20"].map((tip) => (
                <label
                  key={tip}
                  className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                    tipPercentage === tip ? "border-primary bg-primary/5" : "border-border"
                  }`}
                  data-testid={`radio-tip-${tip}`}
                >
                  <RadioGroupItem value={tip} id={`tip-${tip}`} />
                  <span className="font-medium">{tip}%</span>
                </label>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tip-people" className="text-sm font-medium uppercase tracking-wide">
              Number of People
            </Label>
            <Input
              id="tip-people"
              data-testid="input-tip-people"
              type="number"
              min="1"
              placeholder="Enter number of people"
              value={numberOfPeople}
              onChange={(e) => setNumberOfPeople(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateTip}
              className="flex-1 h-12"
              disabled={!billAmount || isCalculating}
              data-testid="button-calculate-tip"
            >
              {isCalculating ? "Calculating..." : "Calculate Tip"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-tip"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Bill Summary</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Tip Amount ({tipPercentage}%):</span>
                <span className="text-lg font-bold font-mono text-secondary" data-testid="text-tip-amount">
                  ₹{result.tipAmount.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Total Amount:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-tip-total">
                  ₹{result.totalAmount.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Per Person:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-tip-per-person">
                  ₹{result.perPersonAmount.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
