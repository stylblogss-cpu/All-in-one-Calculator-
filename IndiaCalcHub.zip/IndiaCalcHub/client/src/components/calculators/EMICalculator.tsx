import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Calculator, Info } from "lucide-react";

export function EMICalculator() {
  const [principal, setPrincipal] = useState("");
  const [rate, setRate] = useState("");
  const [tenure, setTenure] = useState(12);
  const [result, setResult] = useState<{
    emi: number;
    totalInterest: number;
    totalAmount: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateEMI = () => {
    const p = parseFloat(principal);
    const r = parseFloat(rate);
    const t = tenure;

    if (isNaN(p) || isNaN(r) || p <= 0 || r <= 0 || t <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      const monthlyRate = r / 12 / 100;
      const emi =
        (p * monthlyRate * Math.pow(1 + monthlyRate, t)) /
        (Math.pow(1 + monthlyRate, t) - 1);
      const totalAmount = emi * t;
      const totalInterest = totalAmount - p;

      setResult({
        emi: Math.round(emi * 100) / 100,
        totalInterest: Math.round(totalInterest * 100) / 100,
        totalAmount: Math.round(totalAmount * 100) / 100,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setPrincipal("");
    setRate("");
    setTenure(12);
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Calculator className="h-6 w-6 text-primary" />
          Loan EMI Calculator
        </CardTitle>
        <CardDescription>
          Calculate your monthly loan EMI and total interest payable
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="emi-principal" className="text-sm font-medium uppercase tracking-wide">
              Loan Amount (₹)
            </Label>
            <Input
              id="emi-principal"
              data-testid="input-emi-principal"
              type="number"
              placeholder="Enter loan amount"
              value={principal}
              onChange={(e) => setPrincipal(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="emi-rate" className="text-sm font-medium uppercase tracking-wide">
              Interest Rate (% per annum)
            </Label>
            <Input
              id="emi-rate"
              data-testid="input-emi-rate"
              type="number"
              step="0.1"
              placeholder="Enter interest rate"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label className="text-sm font-medium uppercase tracking-wide">
                Loan Tenure (Months)
              </Label>
              <span className="text-lg font-bold font-mono text-primary" data-testid="text-emi-tenure">
                {tenure}
              </span>
            </div>
            <Slider
              value={[tenure]}
              onValueChange={(value) => setTenure(value[0])}
              min={1}
              max={360}
              step={1}
              className="w-full"
              data-testid="slider-emi-tenure"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>1 month</span>
              <span>30 years (360 months)</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateEMI}
              className="flex-1 h-12"
              disabled={!principal || !rate || isCalculating}
              data-testid="button-calculate-emi"
            >
              {isCalculating ? "Calculating..." : "Calculate EMI"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-emi"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Results</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Monthly EMI:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-emi-monthly">
                  ₹{result.emi.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Total Interest:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-emi-interest">
                  ₹{result.totalInterest.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Total Amount Payable:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-emi-total">
                  ₹{result.totalAmount.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
