import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calendar, Info } from "lucide-react";

export function AgeCalculator() {
  const [birthDate, setBirthDate] = useState("");
  const [result, setResult] = useState<{
    years: number;
    months: number;
    days: number;
    totalDays: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateAge = () => {
    if (!birthDate) return;

    setIsCalculating(true);
    setTimeout(() => {
      const birth = new Date(birthDate);
      const today = new Date();

      let years = today.getFullYear() - birth.getFullYear();
      let months = today.getMonth() - birth.getMonth();
      let days = today.getDate() - birth.getDate();

      if (days < 0) {
        months--;
        const previousMonth = new Date(today.getFullYear(), today.getMonth(), 0);
        days += previousMonth.getDate();
      }

      if (months < 0) {
        years--;
        months += 12;
      }

      const totalDays = Math.floor((today.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));

      setResult({ years, months, days, totalDays });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setBirthDate("");
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Calendar className="h-6 w-6 text-primary" />
          Age Calculator
        </CardTitle>
        <CardDescription>
          Calculate your exact age in years, months, and days
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="age-birthdate" className="text-sm font-medium uppercase tracking-wide">
              Date of Birth
            </Label>
            <Input
              id="age-birthdate"
              data-testid="input-age-birthdate"
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              max={new Date().toISOString().split("T")[0]}
              className="h-12 text-base"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateAge}
              className="flex-1 h-12"
              disabled={!birthDate || isCalculating}
              data-testid="button-calculate-age"
            >
              {isCalculating ? "Calculating..." : "Calculate Age"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-age"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Your Age</h3>
            </div>
            <div className="grid gap-3">
              <div className="grid grid-cols-3 gap-3">
                <div className="p-4 bg-primary/10 rounded-lg border-2 border-primary/20 text-center">
                  <div className="text-3xl font-bold font-mono text-primary" data-testid="text-age-years">
                    {result.years}
                  </div>
                  <div className="text-xs font-medium text-muted-foreground mt-1">Years</div>
                </div>
                <div className="p-4 bg-primary/10 rounded-lg border-2 border-primary/20 text-center">
                  <div className="text-3xl font-bold font-mono text-primary" data-testid="text-age-months">
                    {result.months}
                  </div>
                  <div className="text-xs font-medium text-muted-foreground mt-1">Months</div>
                </div>
                <div className="p-4 bg-primary/10 rounded-lg border-2 border-primary/20 text-center">
                  <div className="text-3xl font-bold font-mono text-primary" data-testid="text-age-days">
                    {result.days}
                  </div>
                  <div className="text-xs font-medium text-muted-foreground mt-1">Days</div>
                </div>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Total Days Lived:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-age-total-days">
                  {result.totalDays.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
