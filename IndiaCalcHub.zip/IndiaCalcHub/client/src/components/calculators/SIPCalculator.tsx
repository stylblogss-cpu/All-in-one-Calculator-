import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { TrendingUp, Info } from "lucide-react";

export function SIPCalculator() {
  const [monthlyInvestment, setMonthlyInvestment] = useState("");
  const [expectedReturn, setExpectedReturn] = useState("");
  const [tenure, setTenure] = useState(12);
  const [result, setResult] = useState<{
    totalInvestment: number;
    estimatedReturns: number;
    totalValue: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateSIP = () => {
    const p = parseFloat(monthlyInvestment);
    const r = parseFloat(expectedReturn);
    const t = tenure;

    if (isNaN(p) || isNaN(r) || p <= 0 || r <= 0 || t <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      const monthlyRate = r / 12 / 100;
      const n = t;
      
      const futureValue = p * (((Math.pow(1 + monthlyRate, n) - 1) / monthlyRate) * (1 + monthlyRate));
      const totalInvestment = p * n;
      const estimatedReturns = futureValue - totalInvestment;

      setResult({
        totalInvestment: Math.round(totalInvestment * 100) / 100,
        estimatedReturns: Math.round(estimatedReturns * 100) / 100,
        totalValue: Math.round(futureValue * 100) / 100,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setMonthlyInvestment("");
    setExpectedReturn("");
    setTenure(12);
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <TrendingUp className="h-6 w-6 text-primary" />
          SIP Calculator
        </CardTitle>
        <CardDescription>
          Calculate your Systematic Investment Plan returns and wealth growth
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="sip-monthly" className="text-sm font-medium uppercase tracking-wide">
              Monthly Investment (₹)
            </Label>
            <Input
              id="sip-monthly"
              data-testid="input-sip-monthly"
              type="number"
              placeholder="Enter monthly SIP amount"
              value={monthlyInvestment}
              onChange={(e) => setMonthlyInvestment(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sip-return" className="text-sm font-medium uppercase tracking-wide">
              Expected Return Rate (% per annum)
            </Label>
            <Input
              id="sip-return"
              data-testid="input-sip-return"
              type="number"
              step="0.1"
              placeholder="Enter expected return rate"
              value={expectedReturn}
              onChange={(e) => setExpectedReturn(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label className="text-sm font-medium uppercase tracking-wide">
                Investment Period (Months)
              </Label>
              <span className="text-lg font-bold font-mono text-primary" data-testid="text-sip-tenure">
                {tenure}
              </span>
            </div>
            <Slider
              value={[tenure]}
              onValueChange={(value) => setTenure(value[0])}
              min={1}
              max={360}
              step={1}
              className="w-full"
              data-testid="slider-sip-tenure"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>1 month</span>
              <span>30 years (360 months)</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateSIP}
              className="flex-1 h-12"
              disabled={!monthlyInvestment || !expectedReturn || isCalculating}
              data-testid="button-calculate-sip"
            >
              {isCalculating ? "Calculating..." : "Calculate SIP"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-sip"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Investment Summary</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Total Investment:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-sip-invested">
                  ₹{result.totalInvestment.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Estimated Returns:</span>
                <span className="text-lg font-bold font-mono text-secondary" data-testid="text-sip-returns">
                  ₹{result.estimatedReturns.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Total Value:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-sip-total">
                  ₹{result.totalValue.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
