import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { PiggyBank, Info } from "lucide-react";

export function PPFCalculator() {
  const [yearlyInvestment, setYearlyInvestment] = useState("");
  const [tenure, setTenure] = useState(15);
  const [result, setResult] = useState<{
    totalInvestment: number;
    interestEarned: number;
    maturityAmount: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const PPF_RATE = 7.1;

  const calculatePPF = () => {
    const p = parseFloat(yearlyInvestment);
    const t = tenure;

    if (isNaN(p) || p <= 0 || t < 15) return;

    setIsCalculating(true);
    setTimeout(() => {
      const r = PPF_RATE / 100;
      let maturityAmount = 0;

      for (let year = 1; year <= t; year++) {
        maturityAmount = (maturityAmount + p) * (1 + r);
      }

      const totalInvestment = p * t;
      const interestEarned = maturityAmount - totalInvestment;

      setResult({
        totalInvestment: Math.round(totalInvestment * 100) / 100,
        interestEarned: Math.round(interestEarned * 100) / 100,
        maturityAmount: Math.round(maturityAmount * 100) / 100,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setYearlyInvestment("");
    setTenure(15);
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <PiggyBank className="h-6 w-6 text-primary" />
          PPF Calculator
        </CardTitle>
        <CardDescription>
          Calculate Public Provident Fund maturity amount and interest earned
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="ppf-yearly" className="text-sm font-medium uppercase tracking-wide">
              Yearly Investment (₹)
            </Label>
            <Input
              id="ppf-yearly"
              data-testid="input-ppf-yearly"
              type="number"
              placeholder="Enter yearly PPF amount (max ₹1,50,000)"
              value={yearlyInvestment}
              onChange={(e) => setYearlyInvestment(e.target.value)}
              className="h-12 text-base"
            />
            <p className="text-xs text-muted-foreground">
              Current PPF interest rate: {PPF_RATE}% per annum (compounded annually)
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label className="text-sm font-medium uppercase tracking-wide">
                Investment Period (Years)
              </Label>
              <span className="text-lg font-bold font-mono text-primary" data-testid="text-ppf-tenure">
                {tenure}
              </span>
            </div>
            <Slider
              value={[tenure]}
              onValueChange={(value) => setTenure(value[0])}
              min={15}
              max={50}
              step={1}
              className="w-full"
              data-testid="slider-ppf-tenure"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>15 years (minimum)</span>
              <span>50 years</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculatePPF}
              className="flex-1 h-12"
              disabled={!yearlyInvestment || isCalculating}
              data-testid="button-calculate-ppf"
            >
              {isCalculating ? "Calculating..." : "Calculate PPF"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-ppf"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Maturity Details</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Total Investment:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-ppf-invested">
                  ₹{result.totalInvestment.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Interest Earned:</span>
                <span className="text-lg font-bold font-mono text-secondary" data-testid="text-ppf-interest">
                  ₹{result.interestEarned.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Maturity Amount:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-ppf-maturity">
                  ₹{result.maturityAmount.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
