import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calculator, Info } from "lucide-react";

export function GSTCalculator() {
  const [amount, setAmount] = useState("");
  const [gstRate, setGstRate] = useState("18");
  const [isInclusive, setIsInclusive] = useState(false);
  const [result, setResult] = useState<{
    originalAmount: number;
    gstAmount: number;
    totalAmount: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateGST = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return;

    setIsCalculating(true);
    setTimeout(() => {
      const rate = parseFloat(gstRate) / 100;
      let originalAmount: number;
      let gstAmount: number;
      let totalAmount: number;

      if (isInclusive) {
        totalAmount = numAmount;
        originalAmount = numAmount / (1 + rate);
        gstAmount = numAmount - originalAmount;
      } else {
        originalAmount = numAmount;
        gstAmount = numAmount * rate;
        totalAmount = numAmount + gstAmount;
      }

      setResult({
        originalAmount: Math.round(originalAmount * 100) / 100,
        gstAmount: Math.round(gstAmount * 100) / 100,
        totalAmount: Math.round(totalAmount * 100) / 100,
      });
      setIsCalculating(false);
    }, 300);
  };

  const handleClear = () => {
    setAmount("");
    setResult(null);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl md:text-2xl">
          <Calculator className="h-6 w-6 text-primary" />
          GST Calculator
        </CardTitle>
        <CardDescription>
          Calculate GST inclusive or exclusive amounts for Indian tax rates
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="gst-amount" className="text-sm font-medium uppercase tracking-wide">
              Amount (₹)
            </Label>
            <Input
              id="gst-amount"
              data-testid="input-gst-amount"
              type="number"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="h-12 text-base"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium uppercase tracking-wide">GST Rate</Label>
            <RadioGroup
              value={gstRate}
              onValueChange={setGstRate}
              className="grid grid-cols-2 md:grid-cols-4 gap-3"
            >
              {["5", "12", "18", "28"].map((rate) => (
                <label
                  key={rate}
                  className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                    gstRate === rate ? "border-primary bg-primary/5" : "border-border"
                  }`}
                  data-testid={`radio-gst-${rate}`}
                >
                  <RadioGroupItem value={rate} id={`gst-${rate}`} />
                  <span className="font-medium">{rate}%</span>
                </label>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium uppercase tracking-wide">Calculation Type</Label>
            <RadioGroup
              value={isInclusive ? "inclusive" : "exclusive"}
              onValueChange={(value) => setIsInclusive(value === "inclusive")}
              className="grid grid-cols-1 md:grid-cols-2 gap-3"
            >
              <label
                className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                  !isInclusive ? "border-primary bg-primary/5" : "border-border"
                }`}
                data-testid="radio-gst-exclusive"
              >
                <RadioGroupItem value="exclusive" id="gst-exclusive" />
                <span className="font-medium">Exclusive (Add GST)</span>
              </label>
              <label
                className={`flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover-elevate active-elevate-2 ${
                  isInclusive ? "border-primary bg-primary/5" : "border-border"
                }`}
                data-testid="radio-gst-inclusive"
              >
                <RadioGroupItem value="inclusive" id="gst-inclusive" />
                <span className="font-medium">Inclusive (Remove GST)</span>
              </label>
            </RadioGroup>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={calculateGST}
              className="flex-1 h-12"
              disabled={!amount || isCalculating}
              data-testid="button-calculate-gst"
            >
              {isCalculating ? "Calculating..." : "Calculate GST"}
            </Button>
            {result && (
              <Button
                onClick={handleClear}
                variant="outline"
                className="h-12"
                data-testid="button-clear-gst"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="space-y-3 pt-4 border-t animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 text-secondary">
              <Info className="h-5 w-5" />
              <h3 className="font-semibold text-lg">Results</h3>
            </div>
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">Original Amount:</span>
                <span className="text-lg font-bold font-mono" data-testid="text-gst-original">
                  ₹{result.originalAmount.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                <span className="text-sm font-medium text-muted-foreground">GST Amount ({gstRate}%):</span>
                <span className="text-lg font-bold font-mono text-primary" data-testid="text-gst-amount">
                  ₹{result.gstAmount.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
                <span className="text-base font-semibold">Total Amount:</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-gst-total">
                  ₹{result.totalAmount.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
