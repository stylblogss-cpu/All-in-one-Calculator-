export function Footer() {
  return (
    <footer className="border-t mt-12 py-8 bg-card">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <button
              onClick={() => alert("About: This is a free calculator hub for Indian users.")}
              className="hover:text-foreground transition-colors hover-elevate px-3 py-1 rounded"
              data-testid="link-about"
            >
              About
            </button>
            <span>•</span>
            <button
              onClick={() => alert("Privacy Policy: Your data is not stored or transmitted.")}
              className="hover:text-foreground transition-colors hover-elevate px-3 py-1 rounded"
              data-testid="link-privacy"
            >
              Privacy Policy
            </button>
            <span>•</span>
            <button
              onClick={() => alert("Disclaimer: These calculators are for informational purposes only.")}
              className="hover:text-foreground transition-colors hover-elevate px-3 py-1 rounded"
              data-testid="link-disclaimer"
            >
              Disclaimer
            </button>
          </div>
          <p className="text-xs text-muted-foreground text-center">
            © {new Date().getFullYear()} All-in-One India Calculator Hub. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground text-center">
            Free tools for GST, EMI, BMI, Age, and Income Tax calculations
          </p>
        </div>
      </div>
    </footer>
  );
}
