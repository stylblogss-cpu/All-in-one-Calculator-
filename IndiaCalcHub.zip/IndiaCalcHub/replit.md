# All-in-One India Calculator Hub

## Overview
A responsive single-page calculator portal designed for Indian users, featuring multiple essential calculation tools including GST, EMI, BMI, Age, and Income Tax calculators. The application uses Indian-themed colors (saffron orange and green) representing the national flag, with a modern, mobile-first design.

## Project Purpose
To provide free, easy-to-use calculation tools for common Indian financial, health, and daily needs. All calculations are performed client-side in JavaScript for fast, secure, and private computations.

## Key Features

### Calculators
1. **GST Calculator** (Finance)
   - Calculate GST inclusive or exclusive amounts
   - Support for all Indian GST rates: 5%, 12%, 18%, 28%
   - Shows breakdown of original amount, GST amount, and total

2. **Loan EMI Calculator** (Finance)
   - Calculate monthly EMI for loans
   - Interactive slider for loan tenure (1-360 months)
   - Shows EMI, total interest, and total payable amount

3. **Income Tax Calculator 2025** (Finance)
   - Calculate tax liability under old or new tax regime
   - Updated with 2025 tax slabs
   - Detailed breakdown by tax slab
   - Includes 4% health & education cess

4. **SIP Calculator** (Finance)
   - Calculate Systematic Investment Plan returns
   - Shows total investment, estimated returns, and wealth growth
   - Interactive slider for investment period

5. **PPF Calculator** (Finance)
   - Calculate Public Provident Fund maturity amount
   - Current interest rate: 7.1% per annum
   - Minimum 15 years investment period

6. **Gratuity Calculator** (Finance)
   - Calculate gratuity based on last salary and years of service
   - Eligibility check (minimum 5 years required)
   - Formula: (Salary × Years × 15) ÷ 26

7. **BMI Calculator** (Health)
   - Calculate Body Mass Index
   - Support for both metric (kg, cm) and imperial (lbs, inches) units
   - Health category classification (Underweight, Normal, Overweight, Obese)

8. **Unit Converter** (Conversion)
   - Convert Length/Distance (km, m, cm, miles, feet, inches)
   - Convert Weight/Mass (kg, g, lbs, oz)
   - Convert Temperature (Celsius, Fahrenheit, Kelvin)

9. **Age Calculator** (Daily Tools)
   - Calculate exact age in years, months, and days
   - Shows total days lived
   - Simple date picker interface

10. **Tip Calculator** (Daily Tools)
    - Calculate tip amount with preset percentages (5%, 10%, 15%, 20%)
    - Split bill among multiple people
    - Shows per-person amount

### UI/UX Features
- **Dark Mode**: Toggle between light and dark themes with localStorage persistence
- **Navigation Tabs**: Organized by category (Finance, Health, Daily Tools)
- **Responsive Design**: Mobile-first approach with beautiful layouts on all devices
- **Loading Animations**: Smooth transitions when calculating results
- **Indian Theme**: Saffron orange (primary) and green (secondary) color scheme
- **SEO Optimized**: Meta tags for discoverability
- **AdSense Ready**: Placeholder banner for future monetization

## Technical Architecture

### Frontend Stack
- **React 18** with TypeScript
- **Tailwind CSS** for styling with custom Indian color theme
- **Shadcn UI** components for consistent design
- **Wouter** for client-side routing
- **Lucide React** for icons

### Design System
- **Primary Color**: Saffron Orange (HSL: 26 100% 55%)
- **Secondary Color**: Green (HSL: 138 61% 30%)
- **Typography**: Inter for UI, Roboto Mono for numerical displays
- **Spacing**: Consistent 4-point grid system
- **Shadows**: Subtle elevation for cards and interactive elements

### File Structure
```
client/src/
├── components/
│   ├── calculators/
│   │   ├── GSTCalculator.tsx
│   │   ├── EMICalculator.tsx
│   │   ├── BMICalculator.tsx
│   │   ├── AgeCalculator.tsx
│   │   └── IncomeTaxCalculator.tsx
│   ├── ui/ (Shadcn components)
│   ├── ThemeProvider.tsx
│   └── Footer.tsx
├── pages/
│   ├── Home.tsx (Main calculator hub)
│   └── not-found.tsx
├── App.tsx
└── index.css (Design tokens)
```

### Calculation Logic
All calculations are performed client-side using vanilla JavaScript:
- **GST**: Handles both inclusive and exclusive calculations
- **EMI**: Uses compound interest formula
- **BMI**: Supports metric and imperial conversions
- **Age**: Date arithmetic accounting for varying month lengths
- **Income Tax**: Implements 2025 tax slabs for both old and new regimes

## SEO & Accessibility
- Semantic HTML structure
- Descriptive meta tags for search engines
- ARIA labels for screen readers
- Keyboard navigation support
- High contrast ratios for readability
- data-testid attributes for automated testing

## Recent Changes
- December 2024: Added 4 new calculators (SIP, PPF, Gratuity, Tip)
- Initial project setup with Indian-themed design system
- Implemented all 10 calculators across 4 categories
- Added dark mode toggle functionality with localStorage persistence
- Created responsive navigation with category tabs (Finance, Health, Conversion, Daily Tools)
- Integrated AdSense placeholder banner
- Added footer with About, Privacy Policy, and Disclaimer links
- Smooth loading animations and transitions for all calculations

## Future Enhancements
- Save calculation history in localStorage
- Print/PDF export functionality for calculation results
- Share results via social media
- Multi-language support (Hindi, regional languages)
- Progressive Web App (PWA) capabilities
- Additional calculators (Retirement, FD, RD, Insurance)

## Development Notes
- No backend persistence needed (all client-side)
- No user authentication required
- Calculations are instant with simulated loading for UX
- Theme preference persists in localStorage
- Mobile-optimized with touch-friendly controls
